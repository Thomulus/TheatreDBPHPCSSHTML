	<header>
		<a href="admin.php">
				<img src="images/OMTS.png" alt="OMTS logo"
					title="Admin Page" id="siteLogo"/>
			</a>
			<nav>
				<ul>
					<li><a href="./addmovies.php">Add Movies</a></li>
					<li><a href="./complex.php">Edit Complexes</a></li>
					<li><a href="./members.php">View Customers</a></li>
					<li><a href="./showings.php">Edit Showings</a></li>
					<li><a href="./performance.php">View Performance</a></li>
				</ul>
			</nav>
	</header>
