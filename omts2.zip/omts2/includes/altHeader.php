	<header>
		<a href="test.html">
				<img src="images/OMTS.png" alt="OMTS logo" 
					title="Welcome to OMTS" id="siteLogo"/>
			</a>
	</header>