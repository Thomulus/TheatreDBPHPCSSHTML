	<header>
		<a href="movies.php">
				<img src="images/OMTS.png" alt="OMTS logo"
					title="Welcome to OMTS" id="siteLogo"/>
			</a>
			<nav>
				<ul>
					<li><a href="./movies.php">See Movies</a></li>
					<li><a href="./reservations.php">Reserve a Ticket</a></li>
					<li><a href="./cancel.php">Cancel a Reservation</a></li>
					<li><a href="./past.php">Past Reservations</a></li>
					<li><a href="./writeReview.php">Write A Review</a></li>
					<li><a href="./profile.php">Your Profile</a></li>
				</ul>
			</nav>
	</header>
