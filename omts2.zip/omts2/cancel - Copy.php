<!DOCTYPE html>
<?php include_once "./includes/functions.php"; ?>

<html>

<head>
	<?php printHeadContents("Cancel Reservations"); ?>
</head>

<body>
	<?php include_once "./includes/header.php"; ?>
</body>

</html>